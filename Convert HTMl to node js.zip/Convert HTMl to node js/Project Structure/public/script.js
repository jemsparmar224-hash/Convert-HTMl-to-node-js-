let colors = {};
let lockedColors = new Set();
let savedPalettes = JSON.parse(localStorage.getItem('savedPalettes')) || [];

async function generatePalette() {
    const lockedColorsObj = {};
    lockedColors.forEach(index => {
        lockedColorsObj[index] = colors[index];
    });

    try {
        const response = await fetch('/api/generate-palette', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                count: 5,
                lockedColors: lockedColorsObj
            })
        });

        const data = await response.json();
        colors = data.palette;
        renderPalette();
    } catch (error) {
        console.error('Error generating palette:', error);
        showNotification('Error generating palette!');
    }
}

function renderPalette() {
    const palette = document.getElementById('palette');
    palette.innerHTML = '';

    for (let i = 0; i < 5; i++) {
        const colorBox = document.createElement('div');
        colorBox.className = 'color-box';
        colorBox.style.backgroundColor = colors[i];

        const lockBtn = document.createElement('button');
        lockBtn.className = 'lock-btn';
        lockBtn.innerHTML = lockedColors.has(i) ? '🔒' : '🔓';
        lockBtn.onclick = (e) => {
            e.stopPropagation();
            toggleLock(i);
        };

        const colorCode = document.createElement('div');
        colorCode.className = 'color-code';
        colorCode.textContent = colors[i];

        colorBox.appendChild(lockBtn);
        colorBox.appendChild(colorCode);
        colorBox.onclick = () => copyColor(colors[i]);

        palette.appendChild(colorBox);
    }
}

function toggleLock(index) {
    if (lockedColors.has(index)) {
        lockedColors.delete(index);
    } else {
        lockedColors.add(index);
    }
    renderPalette();
}

function copyColor(color) {
    navigator.clipboard.writeText(color);
    showNotification(`${color} copied!`);
}

function copyAllColors() {
    const allColors = Object.values(colors).join(', ');
    navigator.clipboard.writeText(allColors);
    showNotification('All colors copied!');
}

function savePalette() {
    const paletteArray = Object.values(colors);
    const timestamp = new Date().toLocaleString();

    savedPalettes.push({
        colors: paletteArray,
        timestamp: timestamp
    });

    localStorage.setItem('savedPalettes', JSON.stringify(savedPalettes));
    renderSavedPalettes();
    showNotification('Palette saved!');
}

function renderSavedPalettes() {
    const savedList = document.getElementById('savedList');
    savedList.innerHTML = '';

    if (savedPalettes.length === 0) {
        savedList.innerHTML = '<p style="color: #999;">No saved palettes yet</p>';
        return;
    }

    savedPalettes.reverse().forEach((palette, index) => {
        const actualIndex = savedPalettes.length - 1 - index;
        const item = document.createElement('div');
        item.className = 'saved-item';

        const colorsDiv = document.createElement('div');
        colorsDiv.className = 'saved-colors';

        palette.colors.forEach(color => {
            const colorDiv = document.createElement('div');
            colorDiv.className = 'saved-color';
            colorDiv.style.backgroundColor = color;
            colorDiv.onclick = () => copyColor(color);
            colorDiv.title = color;
            colorsDiv.appendChild(colorDiv);
        });

        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'saved-actions';

        const loadBtn = document.createElement('button');
        loadBtn.textContent = 'Load';
        loadBtn.onclick = () => loadPalette(actualIndex);

        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'Delete';
        deleteBtn.onclick = () => deletePalette(actualIndex);

        actionsDiv.appendChild(loadBtn);
        actionsDiv.appendChild(deleteBtn);

        item.appendChild(colorsDiv);
        item.appendChild(actionsDiv);
        savedList.appendChild(item);
    });

    savedPalettes.reverse();
}

function loadPalette(index) {
    const palette = savedPalettes[index];
    colors = {};
    palette.colors.forEach((color, i) => {
        colors[i] = color;
    });
    lockedColors.clear();
    renderPalette();
    showNotification('Palette loaded!');
}

function deletePalette(index) {
    savedPalettes.splice(index, 1);
    localStorage.setItem('savedPalettes', JSON.stringify(savedPalettes));
    renderSavedPalettes();
    showNotification('Palette deleted!');
}

function showNotification(message) {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.classList.add('show');
    setTimeout(() => {
        notification.classList.remove('show');
    }, 2000);
}

// Initialize
generatePalette();
renderSavedPalettes();

// Spacebar to generate new palette
document.addEventListener('keydown', (e) => {
    if (e.code === 'Space') {
        e.preventDefault();
        generatePalette();
    }
});