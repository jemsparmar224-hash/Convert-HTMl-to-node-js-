# Color Palette Generator - Node.js Edition

A fully functional color palette generator built with Node.js and Express.

## Features
- Generate random color palettes
- Lock favorite colors
- Save and load palettes
- Copy colors to clipboard
- RESTful API endpoints
- Responsive design

## Installation

1. Install dependencies:
```bash
npm install
```

2. Start the server:
```bash
npm start
```

3. For development with auto-reload:
```bash
npm run dev
```



## API Endpoints

- `GET /api/generate-color` - Generate a single random color
- `POST /api/generate-palette` - Generate a palette with locked colors
- `GET /api/color-info/:hex` - Get RGB and HSL values for a color

## Project Structure

```
color-palette-generator/
├── server.js           # Express server
├── package.json        # Dependencies
├── public/
│   ├── index.html     # Main HTML page
│   ├── styles.css     # Styles
│   └── script.js      # Client-side JavaScript
└── README.md          # Documentation
```

## Technologies Used
- Node.js
- Express.js
- Vanilla JavaScript
- CSS3
- HTML5

## License
MIT