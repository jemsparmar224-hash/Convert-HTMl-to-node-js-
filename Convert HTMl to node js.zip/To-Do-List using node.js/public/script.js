let currentFilter = 'all';

// Load todos when page loads
document.addEventListener('DOMContentLoaded', () => {
    loadTodos();
    setupEventListeners();
});

function setupEventListeners() {
    // Add todo
    document.getElementById('addBtn').addEventListener('click', addTodo);
    document.getElementById('todoInput').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') addTodo();
    });

    // Filter buttons
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            currentFilter = e.target.dataset.filter;
            loadTodos();
        });
    });

    // Clear completed
    document.getElementById('clearCompleted').addEventListener('click', clearCompleted);
}

async function loadTodos() {
    try {
        const response = await fetch('/api/todos');
        const todos = await response.json();
        displayTodos(todos);
        updateStats(todos);
    } catch (error) {
        console.error('Error loading todos:', error);
    }
}

function displayTodos(todos) {
    const todoList = document.getElementById('todoList');

    // Filter todos
    let filteredTodos = todos;
    if (currentFilter === 'active') {
        filteredTodos = todos.filter(t => !t.completed);
    } else if (currentFilter === 'completed') {
        filteredTodos = todos.filter(t => t.completed);
    }

    if (filteredTodos.length === 0) {
        todoList.innerHTML = '<div class="empty-state">No tasks to show</div>';
        return;
    }

    todoList.innerHTML = filteredTodos.map(todo => `
    <li class="todo-item ${todo.completed ? 'completed' : ''}" data-id="${todo.id}">
      <input type="checkbox" ${todo.completed ? 'checked' : ''} onchange="toggleTodo(${todo.id})">
      <span>${todo.text}</span>
      <button class="delete-btn" onclick="deleteTodo(${todo.id})">✕</button>
    </li>
  `).join('');
}

async function addTodo() {
    const input = document.getElementById('todoInput');
    const text = input.value.trim();

    if (!text) return;

    try {
        const response = await fetch('/api/todos', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text })
        });

        if (response.ok) {
            input.value = '';
            loadTodos();
        }
    } catch (error) {
        console.error('Error adding todo:', error);
    }
}

async function toggleTodo(id) {
    try {
        await fetch(`/api/todos/${id}`, { method: 'PUT' });
        loadTodos();
    } catch (error) {
        console.error('Error toggling todo:', error);
    }
}

async function deleteTodo(id) {
    try {
        await fetch(`/api/todos/${id}`, { method: 'DELETE' });
        loadTodos();
    } catch (error) {
        console.error('Error deleting todo:', error);
    }
}

async function clearCompleted() {
    try {
        const response = await fetch('/api/todos');
        const todos = await response.json();
        const completed = todos.filter(t => t.completed);

        for (const todo of completed) {
            await fetch(`/api/todos/${todo.id}`, { method: 'DELETE' });
        }

        loadTodos();
    } catch (error) {
        console.error('Error clearing completed:', error);
    }
}

function updateStats(todos) {
    const activeCount = todos.filter(t => !t.completed).length;
    document.getElementById('todoCount').textContent =
        `${activeCount} item${activeCount !== 1 ? 's' : ''} left`;
}